chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
  if (changeInfo.status == 'complete' && tab.active) {


	chrome.cookies.get({ url: 'https://wpga.myschoolapp.com/app/student#studentmyday/', name: 't' },
	  function (cookie) {
	    if (cookie) {
	      console.log("t: " + cookie.value);
	    }
	});

  }
})





  function getSessionStorage() {
    var script = JSON.parse(JSON.stringify(window.sessionStorage))

    chrome.tabs.executeScript({
      code: script
    }, function(results){
        console.log(results); // produces [{}] instead of sessionStorage
    });
  }


function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}