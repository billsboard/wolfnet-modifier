var flag = false;
var showgrades = false;


var div;
var atWrapper;

var wrapper;

var doneTopBar = false

function locationHashChanged() {
  if (location.hash === '#studentmyday/schedule') {
  	var bbtile;
  	function checkForLoaded(){
  		bbtile = document.getElementsByClassName("bb-tile").item(0);
  		if(typeof(bbtile) == "undefined" || !bbtile){
  			window.setTimeout(checkForLoaded, 100); /* this checks the flag every 100 milliseconds*/
  		}
  		else{
  			var dataArr = [];

  			var logo = document.getElementsByClassName("white-fgc sky-nav").item(1)
  			if(!doneTopBar){
  				//logo.remove()
  				/*
	  			var topBar = document.getElementsByClassName("sky-nav logoimg").item(0)

	  			var newTitle = document.createElement("h3")
	  			newTitle.setAttribute("style", "margin-top: 10px")
	  			newTitle.appendChild(document.createTextNode("West Point Grey Academy"))

	  			
	  			authorText = document.createElement("p")
	  			authorText.setAttribute("style", "font-size: 10px")
	  			//authorText.appendChild(document.createTextNode("coded by Bill He Wang"))
	  			newTitle.appendChild(authorText)
				

	  			topBar.appendChild(newTitle)
	  			*/
				
	  			var blueTopNav = document.getElementsByClassName("topnav").item(0)

	  			var lists = blueTopNav.getElementsByTagName("li")

	  			var wolfmailCopy = lists[1].cloneNode()

	  			var wolfmailLink = lists[1].getElementsByTagName("a")[0].cloneNode()
	  			wolfmailLink.setAttribute("href", "http://wnreporter.billweb.ca")


	  			wolfmailCopy.appendChild(wolfmailLink)
	  			wolfmailCopy.getElementsByTagName("a")[0].appendChild(lists[1].getElementsByTagName("a")[0].getElementsByTagName("span")[0].cloneNode())

	  			var wolfmailText = lists[1].getElementsByTagName("a")[0].getElementsByTagName("span")[0].getElementsByTagName("span")[0].cloneNode()
	  			wolfmailText.innerHTML = "WolfNet Modifier Issues Reporter"
	  			wolfmailCopy.getElementsByTagName("a")[0].getElementsByTagName("span")[0].appendChild(wolfmailText)
	  			blueTopNav.appendChild(wolfmailCopy)
	  			doneTopBar = true
  			}





			//var bbtile = document.getElementsByClassName("bb-tile").item(0);
			bbtile.setAttribute("id", "bb-tile");

			wrapper = document.getElementsByClassName("site-main-wrap").item(0);
			wrapper.setAttribute("id", "schedulePage-ID");


			div=document.createElement("div"); 
			div.setAttribute('class', 'grade-display');
			wrapper.appendChild(div);

			var tBWrapper = document.createElement("div");
			tBWrapper.setAttribute("style", "display: flex; justify-content: space-between; align-items: center;");
			div.appendChild(tBWrapper);


			var gradeHeader = document.createElement("h2");

			gradeHeader.setAttribute("class", "bb-tile-header");
			gradeHeader.setAttribute('style', "font: 300 26px \"Blackbaud Sans Condensed\",\"Helvetica Neue Condensed\",\"Arial Narrow\"; color: #282b31; padding: 9px 15px; margin-top: 0px; margin-bottom: 4px;");

			var gradeText = document.createTextNode("Current grades");
			gradeHeader.appendChild(gradeText);
			tBWrapper.appendChild(gradeHeader);

			var gradeDiv = document.createElement('div');
			gradeDiv.setAttribute("class", 'bb-tile-content-section');
			gradeDiv.setAttribute("style", "border-top: 1px solid #e2e3e4; padding-top: 15px; font-size: 18px;");


			div.appendChild(gradeDiv);


			atWrapper = document.createElement("div");
			atWrapper.setAttribute("class", "site-main-wrap");
			atWrapper.setAttribute("id", "attendence-holder");
			atWrapper.setAttribute("style", "margin-top: 10px, width: 1000px;");

			document.body.appendChild(atWrapper);

			var display2 = document.createElement("div");
			display2.setAttribute("class", "grade-display");
			display2.setAttribute("style", "flex: 0 0 30%; margin-right: 50px;");
			atWrapper.appendChild(display2);

			var attendenceHeader = document.createElement("h2");
			attendenceHeader.setAttribute("class", "bb-tile-header");
			attendenceHeader.setAttribute('style', "font: 300 26px \"Blackbaud Sans Condensed\",\"Helvetica Neue Condensed\",\"Arial Narrow\"; color: #282b31; padding: 9px 15px; margin-top: 0px; margin-bottom: 4px;");

			attendenceHeader.appendChild(document.createTextNode("Attendence Records"));

			var attendenceData = document.createElement('div');
			attendenceData.setAttribute("class", 'bb-tile-content-section');
			attendenceData.setAttribute("style", "border-top: 1px solid #e2e3e4; padding-top: 15px; color: black; font-size: 14px");

			var absentU = document.createTextNode('Absent Unexcused: ');
			var absentE = document.createTextNode('Absent Excused: ');
			var lateU = document.createTextNode('Late Unexcused: ');
			var lateE = document.createTextNode('Late Excused: ');
			var schoolF = document.createTextNode('School Function: ');
			var parentE = document.createTextNode('Parent Excused: ');


			display2.appendChild(attendenceHeader);
			display2.appendChild(attendenceData);


			var display3 = document.createElement("div");
			display3.setAttribute("class", "grade-display");
			display3.setAttribute("style", "flex: 0 1 85%; margin-right: 70px;  max-width: 70%;");
			atWrapper.appendChild(display3);

			var assignmentHeader = document.createElement("h2");
			assignmentHeader.setAttribute("class", "bb-tile-header");
			assignmentHeader.setAttribute('style', "font: 300 26px \"Blackbaud Sans Condensed\",\"Helvetica Neue Condensed\",\"Arial Narrow\"; color: #282b31; padding: 9px 15px; margin-top: 0px; margin-bottom: 4px;");

			assignmentHeader.appendChild(document.createTextNode("Upcoming assignments"));
			display3.appendChild(assignmentHeader);


			var assignmentData = document.createElement("div");
			assignmentData.setAttribute("class", "bb-tile-content-section")
			assignmentData.setAttribute("style", "border-top: 1px solid #e2e3e4; padding-top: 15px; color: black; font-size: 14px;");
			display3.appendChild(assignmentData);

			var data = JSON.parse(sessionStorage.getItem("p3.session"));


			var button = document.createElement("button");
			button.setAttribute("style", "height: 30px; margin-right: 15px; background-color: #f3f3f3; color: black;");
			button.innerHTML = "Show grades";
			tBWrapper.appendChild(button);

			button.addEventListener ("click", function() {
			  	if(!showgrades){
			  		button.innerHTML = "Hide grades";
			  		showgrades = true;
			  		toggleGradeState();
			  	}
			  	else{
			  		showgrades = false;
			  		button.innerHTML = "Show grades";
			  		toggleGradeState();
			  	}
			});


			var gradeLevel;

			getGradeLevel(function(response){
				var jsonResponse = JSON.parse(response);
				var arr = [];

				for(var i in jsonResponse){
		    		arr.push([i, jsonResponse[i]]);
				}

				for (var i = 0; i < arr.length; i++){
				    var obj = arr[i];
				    var jsonstring = [obj[1]];
				    var type = jsonstring[0]['CurrentInd']

				    if(type){
				    	gradeLevel = jsonstring[0]['SchoolYearLabel'];
				    	break;
				    };
				}
			});


			function ATWaitForGradeLevel(){
				if(typeof(gradeLevel) == "undefined"){
					window.setTimeout(ATWaitForGradeLevel, 100);
				}
				else{
					getAttendence("https://wpga.myschoolapp.com/api/datadirect/ParentStudentUserAttendance/?userId=" + data.mainbulletin_user + "&personaId=2&schoolYearLabel=" + gradeLevel , function(responseText) {
						var jsonResponse = JSON.parse(responseText);
						var arr = [];

						var uCount = 0;
						var eCount = 0;

						for(var i in jsonResponse){
				    		arr.push([i, jsonResponse[i]]);
						}

						for (var i = 0; i < arr.length; i++){
						    var obj = arr[i];
						    var jsonstring = [obj[1]];
						    var type = jsonstring[0]['category_description'];

						    console.log(jsonstring[0]['reason']);

						    if(type == "Late Unexcused" || type == "Absent Unexcused"){
						    	uCount += parseInt(jsonstring[0]['excuse_count']);
						    }
						    else if(type == "Parent Excused" || type == "School Function" || type == "Late Excused"){
						    	eCount += parseInt(jsonstring[0]['excuse_count']);
						    }



						    var temp = document.createElement("p");
						   	temp.setAttribute("style", "color: black; font-size: 14px");
						   	temp.appendChild(document.createTextNode(type + ": "));

						   	var span = document.createElement("span");
						   	span.setAttribute("style", "color: #004882; padding-left: 10px;");
						   	span.innerHTML = jsonstring[0]['excuse_count'];
						   	temp.appendChild(span);

						   	attendenceData.appendChild(temp);
						}

						var temp4 = document.createElement("p");
						temp4.setAttribute("style", "color: black; font-size: 14px; padding-top: 20px");
						temp4.appendChild(document.createTextNode("Excused Count: "));

						var span1 = document.createElement("span");
						span1.setAttribute("style", "color: #004882; padding-right: 30px; padding-left: 10px");
						span1.innerHTML = eCount;
						temp4.appendChild(span1);

						temp4.appendChild(document.createTextNode("Unexcused Count: "));

						var span2 = document.createElement("span");
						span2.setAttribute("style", "color: #004882; padding-left: 10px");
						span2.innerHTML = uCount;

						temp4.appendChild(span2);

						attendenceData.appendChild(temp4);

					});
				}
			}

			ATWaitForGradeLevel();

			var spanGradeIndex = new Object();


			function checkFlag() {
			    if(typeof(gradeLevel) == "undefined") {
			       window.setTimeout(checkFlag, 100); /* this checks the flag every 100 milliseconds*/
			    } else {
			    	console.log(gradeLevel.substring(0,4) + "+-+" + gradeLevel.substring(7))
			      	getGrades("https://wpga.myschoolapp.com/api/datadirect/ParentStudentUserAcademicGroupsGet?userId=" + data.mainbulletin_user + "&memberLevel=3&persona=2&schoolYearLabel="
					 + gradeLevel.substring(0,4) + "+-+" + gradeLevel.substring(7) + "&durationList=116252",function(response){
							var jsonResponse = JSON.parse(response);
							var arr = [];

							for(var i in jsonResponse){
					    		arr.push([i, jsonResponse[i]]);
					    		dataArr.push([i, jsonResponse[i]]);
							}

							gradeDiv.innerHTML = "";

							if(arr === undefined || arr.length == 0){
							    var temp1 =  document.createElement("p");
							    temp1.appendChild(document.createTextNode("No grade data to be fetched"));
							    temp1.setAttribute("style", "color: black; font-size: 14px;");
								gradeDiv.setAttribute("style", "border-top: 1px solid #e2e3e4; padding-top: 15px; text-align: center;");
								gradeDiv.appendChild(temp1);
								return;
							}

							gradeDiv.innerHTML = "";
							var temp5 = document.createElement("p")
							temp5.setAttribute("style", "color: black; font-size: 14px; text-align: center;");
							temp5.appendChild(document.createTextNode("Current Average: "))
							var span3 = document.createElement("span")
							span3.setAttribute("style","color: #004882; padding-left: 10px");
							temp5.appendChild(span3)
							gradeDiv.appendChild(temp5)


							var sum = 0
							var subjects = 0


							for (var i = 0; i < arr.length; i++){
							    var obj = arr[i];
							    var jsonstring = [obj[1]];

							    var currentMark;
							    var rawMark

							    if(!showgrades){
							    	currentMark = "Grade hidden";
							    	rawMark = parseInt(jsonstring[0]['cumgrade']);
							    }
							    else if(!jsonstring[0]['cumgrade']){
							    	currentMark = "---"
							    	rawMark = NaN
							    }
							    else{
							    	currentMark = jsonstring[0]['cumgrade'];
							    	rawMark = parseInt(jsonstring[0]['cumgrade']);
							    }

							    if(!jsonstring[0]['sectionidentifier'].startsWith("Student Reflections")){
							    	var temp1 =  document.createElement("p");

								    temp1.appendChild(document.createTextNode(jsonstring[0]['sectionidentifier'] + ":      "));
								    var span = document.createElement("span");
								    span.appendChild(document.createTextNode("    " + currentMark));
								    span.setAttribute("style","color: #004882; padding-left: 10px");
									temp1.appendChild(span);
								    temp1.setAttribute("style", "color: black; font-size: 14px");
								    span.classData = jsonstring[0]['cumgrade']
									


								    span.onclick = function(){
								    	console.log(this.classData)
										if(this.innerHTML.includes("Grade hidden")){
											if(!this.classData){
												currentMark = "---"
											}
											else{
												currentMark = this.classData
											}
											this.innerHTML = "    " + currentMark;
										}
										else{
											this.innerHTML = "    Grade hidden"
										}
								    }



								    gradeDiv.appendChild(temp1);
								    
								    /*temp1 = document.createElement("p");
								    temp1.appendChild(document.createTextNode(currentMark));

								    temp1.setAttribute("style", "color: blue;");
								    gradeDiv.appendChild(temp1);*/

								    
								    temp1 =  document.createElement("p");
								    temp1.appendChild(document.createTextNode("(Instructor: " + jsonstring[0]['groupownername'] + ")"));
								    temp1.setAttribute("style", "color: black; font-size: 8px;");


								    gradeDiv.appendChild(temp1);
								    }


								    if(!Number.isNaN(rawMark)){
									    sum += rawMark
								    	subjects += 1
								    }


							}

							span3.average = (sum/subjects).toFixed(2)
							if(showgrades){
								span3.appendChild(document.createTextNode((sum/subjects).toFixed(2)))
							}
							else{
								span3.appendChild(document.createTextNode("Average hidden"))
							}

							span3.onclick = function(){
								if(this.innerHTML.includes("Average hidden")){
									if(!this.average){
										this.innerHTML = "    ---"
									}
									else{
										this.innerHTML = "    " + span3.average
									}
								}
								else{
									this.innerHTML = "    Average hidden"
								}
							}
							


							
					});
			    }
			}

			checkFlag();

			function toggleGradeState(){
				gradeDiv.innerHTML = "";
				
				if(typeof dataArr == "undefined"){return;}
				else if(dataArr.length == 0){
				    var temp1 =  document.createElement("p");
				    temp1.appendChild(document.createTextNode("No grade data to be fetched"));
					temp1.setAttribute("style", "color: black; font-size: 14px;");
					gradeDiv.setAttribute("style", "border-top: 1px solid #e2e3e4; padding-top: 15px; text-align: center;");
					gradeDiv.appendChild(temp1);
				}
				else{
					gradeDiv.innerHTML = "";
							var temp5 = document.createElement("p")
							temp5.setAttribute("style", "color: black; font-size: 14px; text-align: center;");
							temp5.appendChild(document.createTextNode("Current Average: "))
							var span3 = document.createElement("span")
							span3.setAttribute("style","color: #004882; padding-left: 10px");
							temp5.appendChild(span3)
							gradeDiv.appendChild(temp5)

							var sum = 0
							var subjects = 0

							for (var i = 0; i < dataArr.length; i++){
							    var obj = dataArr[i];
							    var jsonstring = [obj[1]];

							    var currentMark;
							    var rawMark;

							    if(!showgrades){
							    	currentMark = "Grade hidden";
							    	rawMark = parseInt(jsonstring[0]['cumgrade'])

							    }
							    else if(!jsonstring[0]['cumgrade']){
							    	currentMark = "---"
							    	rawMark = NaN
							    }
							    else{
							    	currentMark = jsonstring[0]['cumgrade'];
							    	rawMark = parseInt(jsonstring[0]['cumgrade'])
							    }

							    if(!jsonstring[0]['sectionidentifier'].startsWith("Student Reflections")){
							    	var temp1 =  document.createElement("p");

								    temp1.appendChild(document.createTextNode(jsonstring[0]['sectionidentifier'] + ":      "));
								    var span = document.createElement("span");
								    span.appendChild(document.createTextNode("    " + currentMark));
								    span.setAttribute("style","color: #004882; padding-left: 10px");
									temp1.appendChild(span);
								    temp1.setAttribute("style", "color: black; font-size: 14px");
								    gradeDiv.appendChild(temp1);

								    span.classData = jsonstring[0]['cumgrade']
									


								    span.onclick = function(){
								    	console.log(this.classData)
										if(this.innerHTML.includes("Grade hidden")){
											if(!this.classData){
												currentMark = "---"
											}
											else{
												currentMark = this.classData
											}
											this.innerHTML = "    " + currentMark;
										}
										else{
											this.innerHTML = "    Grade hidden"
										}
								    }
								    
								    /*temp1 = document.createElement("p");
								    temp1.appendChild(document.createTextNode(currentMark));

								    temp1.setAttribute("style", "color: blue;");
								    gradeDiv.appendChild(temp1);*/


								    
								    temp1 =  document.createElement("p");
								    temp1.appendChild(document.createTextNode("(Instructor: " + jsonstring[0]['groupownername'] + ")"));
								    temp1.setAttribute("style", "color: black; font-size: 8px;");
								    gradeDiv.appendChild(temp1);
									if(!Number.isNaN(rawMark)){
								    	console.log(rawMark)
									    sum += rawMark
								    	subjects += 1
									}
								}

							}
							span3.average = (sum/subjects).toFixed(2)
							if(showgrades){
								span3.appendChild(document.createTextNode((sum/subjects).toFixed(2)))
							}
							else{
								span3.appendChild(document.createTextNode("Average hidden"))
							}
							
							span3.onclick = function(){
								if(this.innerHTML.includes("Average hidden")){
									if(!this.average){
										this.innerHTML = "    ---"
									}
									else{
										this.innerHTML = "    " + span3.average
									}
								}
								else{
									this.innerHTML = "    Average hidden"
								}
							}


				}	
			}

			var weekStart = new Date();
			var formattedStart = (weekStart.getMonth() + 1) + "/" + weekStart.getDate() + "/" + weekStart.getFullYear();

			var weekEnd = new Date(Date.now() + 12096e5);
			var formattedEnd = (weekEnd.getMonth() + 1) + "/" + weekEnd.getDate() + "/" + weekEnd.getFullYear();
 
			getAssignments("https://wpga.myschoolapp.com/api/DataDirect/AssignmentCenterAssignments/?format=json&filter=1&dateStart=" + encodeURIComponent(formattedStart) +
				"&dateEnd=" + encodeURIComponent(formattedEnd) + "&persona=2&statusList=&sectionList=", function(response){
					assignmentData.innerHTML = "";
					if(response == "[]"){
						assignmentData.setAttribute("style", "text-align: center; border-top: 1px solid #e2e3e4; padding-top: 15px; color: black; font-size: 14px")
						assignmentData.appendChild(document.createTextNode("No data to display here"));
					}
					else{
						var jsonResponse = JSON.parse(response);
						var arr = [];

						for(var i in jsonResponse){
				    		arr.push(jsonResponse[i]);
						}

						arr.sort(date_sort);

						var iterationLength = 8;

						if(arr.length < 8){
							iterationLength = arr.length;
						}

						/*assignmentData.style.display = "flex"
						assignmentData.style['justify-content'] = "space-between"
						assignmentData.style['flex-wrap'] = "wrap"*/


						for (var i = 0; i < iterationLength; i++){
							var jsonstring = arr[i];

							var desc = jsonstring['short_description'].replace(/<[^>]*>?/gm, '');

							var assignmentID = jsonstring['assignment_id']
							var indexID = jsonstring['assignment_index_id']

							var link = "#assignmentdetail/" + assignmentID + "/" + indexID + "/0/studentmyday--assignment-center"


							container2 = document.createElement("container");
							container2.setAttribute("style", "display: flex; justify-content: space-between; flex-basis: 0;")

							classColumn = document.createElement("column");
							descColumn = document.createElement("column");
							dueColumn = document.createElement("column");

							classColumn.setAttribute("id", "assignment-column");
							descColumn.setAttribute("id", "assignment-column");
							dueColumn.setAttribute("id", "assignment-column");

							classColumn.setAttribute("style", "padding-left: 10px; flex: 0 1 20%")
							descColumn.setAttribute("style", "text-align: center; max-width: 60%; word-wrap: break-word; max-lines: 2")
							dueColumn.setAttribute("style", "padding-right: 0px;")



							container2.appendChild(classColumn);
							container2.appendChild(descColumn);
							container2.appendChild(dueColumn);

							assignmentData.appendChild(container2)

							var assign = document.createElement("p")
							aElement = document.createElement("a")
							aElement.href = link
							
							aElement.appendChild(document.createTextNode(desc))

							assign.appendChild(aElement)

							var dateP = document.createElement("p")
							dateP.setAttribute("style", "color: #004882")							
							dateP.appendChild(document.createTextNode(jsonstring['groupname'].split(" - ")[0]))

							var temp6 = document.createElement("a")
							temp6.setAttribute("href", "https://wpga.myschoolapp.com/app/student#academicclass/" + jsonstring['section_id'] + "/0/bulletinboard")
							temp6.appendChild(dateP)

							classColumn.appendChild(temp6)
							descColumn.appendChild(assign)
							dueColumn.appendChild(document.createTextNode(jsonstring['date_due']))


						}

					}
				});
  		}
  	}

  	checkForLoaded();


    
  }
  else if(flag){
  	//chrome.runtime.sendMessage({text: "reload"}, function(response) {
	//});

	//Remove Injected divs
	div.remove();
	atWrapper.remove();

	//Reset styling
	wrapper.setAttribute("id", "");
	wrapper.setAttribute("style", "");
  }

  flag = true;
}

window.onhashchange = locationHashChanged;

locationHashChanged();


function toggleIndividualGradeState(span, mark){
	console.log("excuted")
	if(span.innerHTML != "Grade Hidden"){
		span.innerHTML = ""
		span.appendChild(document.createTextNode("    " + mark))
	}
	else{
		span.innerHTML = "Grade Hidden"
	}
}

function getGrades(theUrl, callback)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() { 
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200)
            callback(xmlHttp.responseText);
    }
    xmlHttp.open("GET", theUrl, true); // true for asynchronous 
    xmlHttp.setRequestHeader("accept", "application/json, text/javascript, */*; q=0.01");
    xmlHttp.setRequestHeader("accept-language", "en-GB,en-US;q=0.9,en;q=0.8,zh-CN;q=0.7,zh;q=0.6");
    xmlHttp.send();//JSON.stringify({"scheduleDate": "6/3/2019", "personaId": "2"}));
}

function getGradeLevel(callback)
{
	var theUrl = "https://wpga.myschoolapp.com/api/datadirect/StudentGradeLevelList/"
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() { 
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200)
            callback(xmlHttp.responseText);
    }
    xmlHttp.open("GET", theUrl, true); // true for asynchronous 
    xmlHttp.setRequestHeader("accept", "application/json, text/javascript, */*; q=0.01");
    xmlHttp.setRequestHeader("accept-language", "en-GB,en-US;q=0.9,en;q=0.8,zh-CN;q=0.7,zh;q=0.6");
    xmlHttp.send();//JSON.stringify({"scheduleDate": "6/3/2019", "personaId": "2"}));
}

function getAttendence(theUrl, callback)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() { 
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200)
            callback(xmlHttp.responseText);
    }
    xmlHttp.open("GET", theUrl, true); // true for asynchronous 
    xmlHttp.setRequestHeader("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3");
    xmlHttp.setRequestHeader("accept-language", "en-GB,en-US;q=0.9,en;q=0.8,zh-CN;q=0.7,zh;q=0.6");
    xmlHttp.setRequestHeader("cache-control", "max-age=0");
    xmlHttp.setRequestHeader("upgrade-insecure-requests", "1");
    xmlHttp.setRequestHeader("content-type", "application-/json");
    xmlHttp.send();//JSON.stringify({"scheduleDate": "6/3/2019", "personaId": "2"}));
}

function getAssignments(theUrl, callback){
	var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() { 
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200)
            callback(xmlHttp.responseText);
    }
    xmlHttp.open("GET", theUrl, true); // true for asynchronous 
    xmlHttp.setRequestHeader("accept", "application/json, text/javascript, */*; q=0.01");
    xmlHttp.setRequestHeader("accept-language", "en-GB,en-US;q=0.9,en;q=0.8,zh-CN;q=0.7,zh;q=0.6");
    xmlHttp.send();
}

function startOfWeek(d) {
  d = new Date(d);
  var day = d.getDay(),
      diff = d.getDate() - day; // adjust when day is sunday
  return new Date(d.setDate(diff));
}

function endOfWeek(d)
  {
     
    var lastday = d.getDate() - (d.getDay() - 1) + 6;
    return new Date(d.setDate(lastday));
 
  }

function date_sort(a, b) {
    return new Date(a.date_due).getTime() - new Date(b.date_due).getTime();
}

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};


function copy(mainObj) {
  let objCopy = {}; // objCopy will store a copy of the mainObj
  let key;

  for (key in mainObj) {
    objCopy[key] = mainObj[key]; // copies each property to the objCopy object
  }
  return objCopy;
}